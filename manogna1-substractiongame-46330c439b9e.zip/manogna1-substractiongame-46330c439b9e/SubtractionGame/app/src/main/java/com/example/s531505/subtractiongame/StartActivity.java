package com.example.s531505.subtractiongame;

import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

public class StartActivity extends AppCompatActivity
        implements Player1Fragment.Player1Control,Player2Fragment.Player2Control  {



    private String myPlayer = "Unknown";
    String player1 = "Unknown";
    String player2 = "Unknown";
    private int myCount = 0;
int coin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        Intent init=getIntent();
        player1=init.getStringExtra("player1");
        player2=init.getStringExtra("player2");
        int cn=init.getIntExtra("coins",12);
       myCount=cn;
       coin=cn;
        Toast.makeText(StartActivity.this,
                "Lets start the game", Toast.LENGTH_LONG).show();
        if (savedInstanceState != null)
            return;
        Player1Fragment firstFragment = new Player1Fragment();
        firstFragment.setArguments(getIntent().getExtras());
        FragmentTransaction transaction =
                getSupportFragmentManager().beginTransaction();
        transaction.add(R.id.fragLY, firstFragment);
        transaction.commit();
        myPlayer=player1;
        TextView tv=findViewById(R.id.displayTV);
        tv.setText("There are "+myCount+" coins.");
        TextView tv1=findViewById(R.id.tv);
        tv1.setText(myPlayer+" , its your turn take coins");
    }

    @Override
    public void player1takes(int count) {
        TextView tv=findViewById(R.id.displayTV);
        tv.setText("There are "+myCount+" coins.");
        myPlayer=player1;
        TextView tv1=findViewById(R.id.tv);
        tv1.setText(myPlayer+" , its your turn take coins");
        try{
                Toast.makeText(StartActivity.this,
                        myPlayer+" took "+count+" coins", Toast.LENGTH_LONG).show();
        myCount=myCount-count;

String str="There are "+myCount+" coins.";
       // TextView tv=findViewById(R.id.displayTV);
        tv.setText(str);
            Player2Fragment firsFragment = new Player2Fragment();
            firsFragment.setArguments(getIntent().getExtras());
            FragmentTransaction transaction =
                    getSupportFragmentManager().beginTransaction();
        if(myCount<=0){
            tv.setText("Congratulations "+myPlayer+"!!! You did it");
            TextView tvv=findViewById(R.id.tv);
            tvv.setText("Click new game to start another game");
            Toast.makeText(StartActivity.this,
                    "Hurray!!! "+myPlayer+" WON, Click RESET to start new game", Toast.LENGTH_LONG).show();
            transaction.replace(R.id.fragLY, firsFragment);
            transaction.hide(firsFragment);
            transaction.commit();
        }else{
        transaction.replace(R.id.fragLY, firsFragment);
        transaction.commit();
            myPlayer=player2;
            tv1.setText(myPlayer+" , its your turn take coins");}}
        catch(Exception ex){
tv.setText("error occured");
        }
    }

    @Override
    public void player2takes(int count) {
            Toast.makeText(StartActivity.this,
                    myPlayer+" took "+count+" coins", Toast.LENGTH_LONG).show();
        myCount=myCount-count;
        myPlayer=player2;
        String str="There are "+myCount+" coins.";
        TextView tv=findViewById(R.id.displayTV);
        tv.setText(str);
        Player1Fragment firstFragment = new Player1Fragment();
        firstFragment.setArguments(getIntent().getExtras());
        FragmentTransaction transaction =
                getSupportFragmentManager().beginTransaction();
        if(myCount<=0){
            tv.setText("Congratulations "+myPlayer+"!!! You did it");
            TextView tvv=findViewById(R.id.tv);
            tvv.setText("Click new game to start another game");
            Toast.makeText(StartActivity.this,
                    "Hurray!!! "+myPlayer+" WON, Click RESET to start new game", Toast.LENGTH_LONG).show();
            transaction.replace(R.id.fragLY, firstFragment);
            transaction.hide(firstFragment);
            transaction.commit();

        }else{
        transaction.replace(R.id.fragLY, firstFragment);
        transaction.commit();
        myPlayer=player1;
            TextView tv1=findViewById(R.id.tv);
            tv1.setText(myPlayer+" , its your turn take coins");}
    }
    public void reset(View v){
        Player1Fragment firstFragment = new Player1Fragment();
        firstFragment.setArguments(getIntent().getExtras());
        FragmentTransaction transaction =
                getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragLY, firstFragment);
        transaction.commit();
        myPlayer=player1;
        myCount=coin;
        TextView tv=findViewById(R.id.displayTV);
        tv.setText("There are "+myCount+" coins.");
        TextView tv1=findViewById(R.id.tv);
        tv1.setText(myPlayer+" , its your turn take coins");
    }
    public void newgame(View v){
        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(i);
    }
}
