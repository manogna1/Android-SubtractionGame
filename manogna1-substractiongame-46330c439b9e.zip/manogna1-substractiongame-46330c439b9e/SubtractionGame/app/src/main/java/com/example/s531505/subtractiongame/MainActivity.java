package com.example.s531505.subtractiongame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    String player1;
    String player2;
    String coins;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    int i;
    public void start(View V) {
        Intent i = new Intent(getApplicationContext(), StartActivity.class);
        EditText et1 = findViewById(R.id.et1);
        EditText et2 = findViewById(R.id.et2);
        EditText et3 = findViewById(R.id.et3);
        String player1 = et1.getText().toString();
        String player2 = et2.getText().toString();
        String coins = et3.getText().toString();
        try {
        Integer cn = Integer.parseInt(coins);
        i.putExtra("player1", player1);
        i.putExtra("player2", player2);
        // i.putExtra("coins", coins);
        i.putExtra("coins", cn);

            if (player1.length() != 0 && player2.length() != 0) {
                if (9 < cn && cn < 21) {
                    startActivity(i);
                } else {
                    et3.setText("Enter value 10 to 20");
                }
            } else {
                et1.setText("Enter string before performing activity");
            }
        } catch (Exception ex) {
            TextView tv=findViewById(R.id.tvv);
            tv.setText("Error! To start game you need to enter names and no.of coins you need");
        }
    }
}
